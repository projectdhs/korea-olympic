# Module: main
# Author: Roman V. M.
# Created on: 28.11.2014
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

import sys, os
from urllib.parse import urlencode, parse_qsl
import xbmcplugin, xbmcaddon, xbmc, xbmcgui, xbmcvfs
import json, requests
from datetime import timezone, timedelta, datetime
from bs4 import BeautifulSoup
import time
import re
addonname=xbmcaddon.Addon().getAddonInfo('name')
noMore=0
chList={'1TV' : '11','2TV' : '12'}
heads_ref={'User-Agent' : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36', 'Accept-Language' : 'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7', 'Accept-Encoding' : 'gzip, deflate', 'referer' : 'https://onair.kbs.co.kr/'}
_url = sys.argv[0]
_handle = int(sys.argv[1])

def noUsing(param1):
    mes='파리 올림픽 중계 기간이 지나서 더이상 이 애드온을 사용할 수 없습니다. 해당 애드온은 삭제 바랍니다.'
    img=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','noImage.png')
    list_item = xbmcgui.ListItem(mes)
    list_item.setInfo('video', {'title': mes,
                                        'mediatype': 'video',
                                        'plot' : mes})
    list_item.setArt({'thumb': img,'icon': img})
    list_item.setProperty('IsPlayable', 'false')
    url = get_url(action='play_none', video='ss')
    xbmcplugin.addDirectoryItem(_handle, url, list_item, False)

    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(_handle,cacheToDisc=False)

def get_kbs_schedule2(mode, chKB1):

    if(mode=='download'):
        timestamp=time.time()
        tz = timezone(timedelta(hours=9))
        dt_9 = datetime.fromtimestamp(timestamp, tz)
        
        year=dt_9.year
        month="{:%m}".format(dt_9)
        day="{:%d}".format(dt_9)

        dt_formatted = '%s%s%s'%(year,month,day)

        url = 'https://static.api.kbs.co.kr/mediafactory/v1/schedule/weekly?local_station_code=00&channel_code=11,12&program_planned_date_from=%s&program_planned_date_to=%s'%((dt_formatted,dt_formatted))
        
        data = requests.get(url, headers=heads_ref)
        jso2=json.loads(data.text)

        url = 'https://cfpwwwapi.kbs.co.kr/api/v1/myk/weekly?program_planned_date_from=%s&program_planned_date_to=%s&channel_code=%s'%(dt_formatted,dt_formatted,chKB1)
        data = requests.get(url, headers=heads_ref)
        jso=json.loads(data.text)

        jso.append(jso2[0])
        jso.append(jso2[1])

        return jso

def get_kbs_schedule3(ch, dat):

    ii=0
    err=0
    timestamp=time.time()
    tz = timezone(timedelta(hours=9))
    dt_9 = datetime.fromtimestamp(timestamp, tz)
    
    year=dt_9.year
    month="{:%m}".format(dt_9)
    day="{:%d}".format(dt_9)
    hour="{:%H}".format(dt_9)
    min="{:%M}".format(dt_9)
    NT = datetime(*(time.strptime('%s%s'%(hour,min), "%H%M")[0:6]))

    for myData in dat:        
        if(myData['channel_code'] == ch):
            ii+=1
            data_item = myData["schedules"]
            for scItem in data_item:
                programStart=scItem['service_start_time'][:4]
                PST = datetime(*(time.strptime(programStart, "%H%M")[0:6]))

                programEnd=scItem['service_end_time'][:4]
                if programEnd == "2400":
                    programEnd = "2359"
                PET = datetime(*(time.strptime(programEnd, "%H%M")[0:6]))
                if((PST<= NT and PET >= NT) or (PST <= NT and PET < PST)):

                    if(scItem['program_planned_date'] == '%s%s%s'%(year,month,day)):
                        programStart=scItem['service_start_time'][:4]
                        try:
                            PST = datetime(*(time.strptime(programStart, "%H%M")[0:6]))
                        except:
                            if(programEnd=='2400'):
                                err=0
                            else:
                                err=1
                            PST = datetime(*(time.strptime('0000', "%H%M")[0:6]))

                        programEnd=scItem['service_end_time'][:4]
                        try:
                            PET = datetime(*(time.strptime(programEnd, "%H%M")[0:6]))
                        except:
                            if(programEnd=='2400'):
                                err=0
                            else:
                                err=1
                            PET = datetime(*(time.strptime('0000', "%H%M")[0:6]))

                        if(err==1):
                            return ['편성 정보 오류',datetime(1970,1,1),datetime(1970,1,1)]

                        return [scItem['program_title'],PST,PET]
                else:
                    continue
    return ['편성 정보가 없습니다.',datetime(1970,1,1),datetime(1970,1,1)]

def parse_line(parsed_json):
    titleList=[]
    codeArr=[]
    imageList=[]
    schList=[]

    ch_item = parsed_json["channel"]

    # KBS1, KBS2 추출
    channel_master = ch_item[0]["channel_master"]
    
    # kbs1
    item1_chname = channel_master[0]["title"]
    item1_image = channel_master[0]["image_path_video_thumbnail"]

    titleList.append("KBS 1TV")
    codeArr.append("11")
    imageList.append(item1_image)


    # kbs2
    item2_chname = channel_master[0]["title"]
    item2_image = channel_master[0]["image_path_video_thumbnail"]

    titleList.append("KBS 2TV")
    codeArr.append("12")
    imageList.append(item2_image)

    # 올림픽 전용 채널
    channel_master = ch_item[1]["channel_master"]

    # 편성표 추출용 코드리스트
    codeList = ""
    for idx, item in enumerate(channel_master):
        chname = item["title"]
        chcode = item["channel_code"]
        chimage = item["image_path_video_thumbnail"]

        titleList.append(chname)
        codeArr.append(chcode)
        imageList.append(chimage)
        codeList += chcode + ","

    codeList = codeList + '11,12'

    scData = get_kbs_schedule2('download', codeList)
    for i in range(0,int(len(codeArr))):
        da=get_kbs_schedule3(codeArr[i], scData)
        schList.append(da)
            
        list_item = xbmcgui.ListItem(titleList[i])
        list_item.setProperty('IsPlayable', 'true')

        list_item.setInfo('video', {'title': titleList[i] + ' - ' + schList[i][0],
                            'mediatype': 'video',
                            'plot' : titleList[i] + ' - ' + schList[i][0] + '\n\n('+"{:%H}".format(schList[i][1])+':'+"{:%M}".format(schList[i][1])+' ~ '+"{:%H}".format(schList[i][2])+':'+"{:%M}".format(schList[i][2])+')'})
        list_item.setArt({'thumb': imageList[i],'icon': imageList[i]})

        url = get_url(action='play_kbs', video=codeArr[i])
        is_folder=False
        xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)

    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(_handle,cacheToDisc=False)

def get_game_k(var):
    if(var=='kbs'):
        url = 'https://onair.kbs.co.kr/index.html?sname=onair&stype=live&ch_code=11&ch_type=globalList'
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        response = requests.get(url, headers=headers)
        lines = response.text.split('\n')
        for line in lines:
            if 'var channelList' in line:
                match = re.search(r"JSON\.parse\('([^']+)'\)", line)
                if match:
                    json_str = match.group(1)
                    json_str = json_str.replace('\\"', '"')
                    parsed_json = json.loads(json_str)
                parse_line(parsed_json)

def get_url(**kwargs):

    return '{0}?{1}'.format(_url, urlencode(kwargs))

def play_video(gid,platform):
    if(platform=='kbs'):
        kurl='https://cfpwwwapi.kbs.co.kr/api/v1/landing/live/channel_code/%s'%(gid)
        htm = requests.get(kurl, headers=heads_ref)
        liveUrl=json.loads(htm.text)["channel_item"][0]["service_url"]

        play_item = xbmcgui.ListItem(path=liveUrl)

        xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)
    else:
        try:
            xbmcgui.Dialog().notification(addonname,'재생할 수 없는 목록입니다.')
        except:
            None


def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if(noMore==1):
        noUsing('olympic')
    if params:
        if params['action'] == 'play_kbs':
            play_video(params['video'], 'kbs')
        elif params['action'] == 'play_none':
            play_video('none', 'none')
        else:
            raise ValueError('Invalid paramstring: {0}!'.format(paramstring))
    else:
        get_game_k('kbs')


if __name__ == '__main__':

    first_date = datetime.now()
    end_date=datetime(2024, 8, 13)
    if(first_date>end_date):
        noMore=1
    router(sys.argv[2][1:])
