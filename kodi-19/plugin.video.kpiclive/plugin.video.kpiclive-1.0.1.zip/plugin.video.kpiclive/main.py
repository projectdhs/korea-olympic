# Module: main
# Author: Roman V. M.
# Created on: 28.11.2014
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

import sys
from urllib.parse import urlencode, parse_qsl
import xbmcgui
import xbmcplugin
import json, requests
from datetime import timezone, timedelta, datetime
import time
noMore=0
heads={'User-Agent' : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36', 'Accept' : 'application/json, text/plain, */*', 'accept-encoding' : 'gzip, deflate, br', 'accept-language' : 'ko-KR,ko;q=0.9', 'referer' : 'https://m.sports.naver.com/tokyo2020/schedule/index'}
_url = sys.argv[0]
_handle = int(sys.argv[1])

def noUsing(param1):
    mes='도쿄 올림픽 중계 기간이 지나서 더이상 이 애드온을 사용할 수 없습니다. 해당 애드온은 삭제 바랍니다.'
    list_item = xbmcgui.ListItem(mes)
    list_item.setInfo('video', {'title': mes,
                                        'mediatype': 'video',
                                        'plot' : mes})
    list_item.setProperty('IsPlayable', 'false')
    url = get_url(action='play', video='ss')
    xbmcplugin.addDirectoryItem(_handle, url, list_item, False)

    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(_handle,cacheToDisc=False)
    
def get_game():

    timestamp=time.time()
    tz = timezone(timedelta(hours=9))
    dt_9 = datetime.fromtimestamp(timestamp, tz)
    
    year=dt_9.year
    month="{:%m}".format(dt_9)
    day="{:%d}".format(dt_9)
    
    url='https://api-gw.sports.naver.com/olympic/tokyo2020/games?fromDate=%s-%s-%s&toDate=%s-%s-%s&liveOrKoreanStarted=true&includeManual=true&sort=liveAndPopular&page=1&pageSize=20&fields=all'%(year,month,day,year,month,day)
    htm_data=requests.get(url, headers=heads)
    if(htm_data.status_code!=200):return ''
    json_data=json.loads(htm_data.text)
    lList=json_data ['result'] ['games']
    
    return lList

def get_url(**kwargs):

    return '{0}?{1}'.format(_url, urlencode(kwargs))

def list_videos(platform):


    if(platform=='naver'):
        gList = get_game()

        for myObj in gList:
            playID=''
            myLAbel=''
            myIsOnair='방송중이 아님'
            if(myObj['gameOnAir'] == True):
                myIsOnair='방송중'
                if(myObj['disciplineName'].strip()=='올림픽'):
                    myLabel = '<지상파 방송중> %s - %s'%(myObj['disciplineName'],myObj['title'])
                elif(myObj['homeTeamCountryName']!='' and myObj['awayTeamCountryName']!=''):
                    myLabel = '<방송중> %s - %s [%s %s : %s %s]'%(myObj['disciplineName'],myObj['title'],myObj['homeTeamCountryName'],myObj['homeTeamScore'],myObj['awayTeamScore'],myObj['awayTeamCountryName'])
                else:
                    myLabel = '<방송중> %s - %s'%(myObj['disciplineName'],myObj['title'])
                list_item = xbmcgui.ListItem(myLabel)
                list_item.setProperty('IsPlayable', 'true')
                if(myObj.get('liveThumbnail')):
                    list_item.setArt({'thumb': myObj['liveThumbnail'],'icon': myObj['liveThumbnail']})
            else:
                if(myObj['homeTeamCountryName']!='' and myObj['awayTeamCountryName']!=''):
                    myLabel = '%s - %s [%s %s : %s %s]'%(myObj['disciplineName'],myObj['title'],myObj['homeTeamCountryName'],myObj['homeTeamScore'],myObj['awayTeamScore'],myObj['awayTeamCountryName'])  
                else:
                    myLabel = '%s - %s'%(myObj['disciplineName'],myObj['title'])  
                list_item = xbmcgui.ListItem(myLabel)
                list_item.setProperty('IsPlayable', 'false')
            if(myObj['koreaPlayer'] == True and myObj['homeTeamCountryName']!=''):
                myInfor='%s %s : %s %s\n\n시간: %s %s - %s\n\n%s'%(myObj['homeTeamCountryName'], myObj['homeTeamScore'], myObj['awayTeamScore'], myObj['awayTeamCountryName'], myObj['gameDate'], myObj['gameDateTime'].split('T')[1][:-3], myIsOnair, myObj['stadium'])
            else:
                myInfor='%s\n\n시간: %s %s - %s'%(myLabel,myObj['gameDate'], myObj['gameDateTime'].split('T')[1][:-3],myIsOnair)
            list_item.setInfo('video', {'title': myLabel,
                                        'mediatype': 'video',
                                        'plot' : myInfor})

            if(myObj['hasDetailGameId'] == True):
                if(myObj.get('detailGameId')):
                    playID=myObj['detailGameId']
                else:
                    playID=myObj['gameId']
            else:
                playID=myObj['gameId']
            url = get_url(action='play', video=playID)


            is_folder = False

            xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)

        xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
        xbmcplugin.endOfDirectory(_handle,cacheToDisc=False)

def play_video(gid):

    n_url_init='https://api-gw.sports.naver.com/schedule/games/'+gid+'/lives'
    s_1=requests.get(n_url_init,headers={'User-Agent' : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36', 'Accept' : 'application/json, text/plain, */*', 'accept-encoding' : 'gzip, deflate, br', 'accept-language' : 'ko-KR,ko;q=0.9', 'referer' : 'https://m.sports.naver.com/game/'+gid})
    if(s_1.status_code!=200):return ''
    jso_1=json.loads(s_1.text)
    r_live_id=jso_1 ['result'] ['lives'][0]['liveId']
    
    rurl='https://proxy-gateway.sports.naver.com/livecloud/lives/%s/playback?countryCode=KR&devt=HTML5_PC&timeMachine=true&p2p=true&includeThumbnail=true'%(r_live_id)
    s_2=requests.get(rurl,headers={'User-Agent' : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36', 'Accept' : 'application/json, text/plain, */*', 'accept-encoding' : 'gzip, deflate, br', 'accept-language' : 'ko-KR,ko;q=0.9', 'referer' : 'https://m.sports.naver.com/game/'+gid})
    if(s_2.status_code!=200):return ''
    jso_2=json.loads(s_2.text)
    stream_url=jso_2['media'] [0] ['path']

    play_item = xbmcgui.ListItem(path=stream_url)

    xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)


def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if(noMore==1):
        noUsing('olympic')
    if params:
        if params['action'] == 'play':
            play_video(params['video'])
        else:
            raise ValueError('Invalid paramstring: {0}!'.format(paramstring))
    else:
        list_videos('naver')


if __name__ == '__main__':

    first_date = datetime.now()
    end_date=datetime(2021, 8, 9)
    if(first_date>end_date):
        noMore=1
    router(sys.argv[2][1:])
