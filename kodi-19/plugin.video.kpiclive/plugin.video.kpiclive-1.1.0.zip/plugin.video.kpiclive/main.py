# Module: main
# Author: Roman V. M.
# Created on: 28.11.2014
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

import sys, os
from urllib.parse import urlencode, parse_qsl
import xbmcplugin, xbmcaddon, xbmc, xbmcgui, xbmcvfs
import json, requests
from datetime import timezone, timedelta, datetime
from bs4 import BeautifulSoup
import time
addonname=xbmcaddon.Addon().getAddonInfo('name')
noMore=0
chList={'1TV' : '11','2TV' : '12'}
heads={'User-Agent' : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36', 'Accept' : 'application/json, text/plain, */*', 'accept-encoding' : 'gzip, deflate, br', 'accept-language' : 'ko-KR,ko;q=0.9', 'referer' : 'https://m.sports.naver.com/tokyo2020/schedule/index'}
heads_kbs={'User-Agent' : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', 'Accept-Language' : 'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7', 'Accept-Encoding' : 'gzip, deflate'}
heads_ref={'User-Agent' : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', 'Accept-Language' : 'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7', 'Accept-Encoding' : 'gzip, deflate', 'referer' : 'https://tokyo2020.kbs.co.kr/live'}
_url = sys.argv[0]
_handle = int(sys.argv[1])

def noUsing(param1):
    mes='도쿄 올림픽 중계 기간이 지나서 더이상 이 애드온을 사용할 수 없습니다. 해당 애드온은 삭제 바랍니다.'
    img=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','noImage.png')
    list_item = xbmcgui.ListItem(mes)
    list_item.setInfo('video', {'title': mes,
                                        'mediatype': 'video',
                                        'plot' : mes})
    list_item.setArt({'thumb': img,'icon': img})
    list_item.setProperty('IsPlayable', 'false')
    url = get_url(action='play_none', video='ss')
    xbmcplugin.addDirectoryItem(_handle, url, list_item, False)

    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(_handle,cacheToDisc=False)
    
def get_kbs_schedule1(mode):

    data = requests.get('https://static.api.kbs.co.kr/mediafactory/v1/schedule/onair_now?rtype=json&channel_code='+chList[mode], headers=heads_ref)
    jso=json.loads(data.text)
    sc=jso[0]['schedules'][0]
    subsc=''
    nowsc='편성 정보가 없습니다.'
    if(sc['program_subtitle']!=None):
        subsc=sc['program_subtitle'].replace('\r\n', ' ')
    if(sc['program_title']!=None):
        nowsc=sc['program_title'].replace('\r\n', ' ')
        
    if not subsc.strip() :
        now_sche='%s'%(nowsc)
    else:
        now_sche='%s - %s'%(nowsc, subsc) 

    programStart=sc['service_start_time'][:4]
    if(programStart=='2400'):
        PST = datetime(*(time.strptime('0000', "%H%M")[0:6]))
    else:
        PST = datetime(*(time.strptime(programStart, "%H%M")[0:6]))
    programEnd=sc['service_end_time'][:4]
    if(programStart=='2400'):
        PET = datetime(*(time.strptime('0000', "%H%M")[0:6]))
    else:
        PET = datetime(*(time.strptime(programEnd, "%H%M")[0:6]))
    return [now_sche, PST, PET]


def get_kbs_schedule2(mode):

    if(mode=='download'):
        timestamp=time.time()
        tz = timezone(timedelta(hours=9))
        dt_9 = datetime.fromtimestamp(timestamp, tz)
        
        year=dt_9.year
        month="{:%m}".format(dt_9)
        day="{:%d}".format(dt_9)
        
        data = requests.get('https://myk2.static.kbs.co.kr/KAPI/nauth/schedule/myk_schedule/list?sdate=%s%s%s&edate=%s%s%s&channel_code=CP03,CP05,CP06,CP07,CP08,CP09,CP10'%(year,month,day,year,month,day), headers=heads_ref)
        jso=json.loads(data.text)
        return jso
def get_kbs_schedule3(ch, dat):

    ii=0
    err=0
    timestamp=time.time()
    tz = timezone(timedelta(hours=9))
    dt_9 = datetime.fromtimestamp(timestamp, tz)
    
    year=dt_9.year
    month="{:%m}".format(dt_9)
    day="{:%d}".format(dt_9)
    hour="{:%H}".format(dt_9)
    min="{:%M}".format(dt_9)
    
    for myData in dat['items']:
        if(myData['channel_code'] == ch):
            ii+=1
            if(myData['program_planned_date'] == '%s%s%s'%(year,month,day)):
                NT = datetime(*(time.strptime('%s%s'%(hour,min), "%H%M")[0:6]))
                programStart=myData['service_start_time'][:4]
                try:
                    PST = datetime(*(time.strptime(programStart, "%H%M")[0:6]))
                except:
                    if(programEnd=='2400'):
                        err=0
                    else:
                        err=1
                    PST = datetime(*(time.strptime('0000', "%H%M")[0:6]))

                programEnd=myData['service_end_time'][:4]
                try:
                    PET = datetime(*(time.strptime(programEnd, "%H%M")[0:6]))
                except:
                    if(programEnd=='2400'):
                        err=0
                    else:
                        err=1
                    PET = datetime(*(time.strptime('0000', "%H%M")[0:6]))

                if(PST<= NT and PET >= NT):

                    return [myData['program_title'],PST,PET]
                elif(myData['broadcast_type']=='1'):

                    return [myData['program_title'],PST,PET]

                if(err==1):
                    return ['편성 정보 오류',datetime(1970,1,1),datetime(1970,1,1)]
    return ['편성 정보가 없습니다.',datetime(1970,1,1),datetime(1970,1,1)]

def get_game_k(var):
    if(var=='kbs'):
        web_ch_list=requests.get('https://tokyo2020.kbs.co.kr/live#', headers=heads_kbs)
        soup = BeautifulSoup(web_ch_list.content, 'html.parser', from_encoding='utf-8')
        soup=soup.find('div', {"class": "vod-aside"})
        rsoup=soup.select('li')
        titleList=[]
        codeList=[]
        imageList=[]
        schList=[]
        for mySoup in rsoup:
            kTitle=mySoup.find('span', {"class": "tit"})
            kCode=mySoup.find('a')['id']
            kImage='https://tokyo2020.kbs.co.kr/'+mySoup.find('img')['src']
            titleList.append(kTitle.text)
            codeList.append(kCode)
            imageList.append(kImage)
        scData = get_kbs_schedule2('download')
        for i in range(0,9):
            if(codeList[i]=='1TV'):
                schList.append(get_kbs_schedule1('1TV'))
            elif(codeList[i]=='2TV'):
                schList.append(get_kbs_schedule1('2TV'))  
            else:
                da=get_kbs_schedule3(codeList[i], scData)
                schList.append(da)
                
            list_item = xbmcgui.ListItem(titleList[i])
            list_item.setProperty('IsPlayable', 'true')

            list_item.setInfo('video', {'title': titleList[i] + ' - ' + schList[i][0],
                                'mediatype': 'video',
                                'plot' : titleList[i] + ' - ' + schList[i][0] + '\n\n('+"{:%H}".format(schList[i][1])+':'+"{:%M}".format(schList[i][1])+' ~ '+"{:%H}".format(schList[i][2])+':'+"{:%M}".format(schList[i][2])+')'})
            list_item.setArt({'thumb': imageList[i],'icon': imageList[i]})
            url = get_url(action='play_kbs', video=codeList[i])
            is_folder=False
            xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)

        xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
        xbmcplugin.endOfDirectory(_handle,cacheToDisc=False)
        #print(titleList[i])
        #print(codeList[i])
        #print(imageList[i])
        #print(schList[i][0])
        #print("{:%H}".format(schList[i][1])+':'+"{:%M}".format(schList[i][1])+' ~ '+"{:%H}".format(schList[i][2])+':'+"{:%M}".format(schList[i][2]))
        #print()
    
def get_game_n():

    timestamp=time.time()
    tz = timezone(timedelta(hours=9))
    dt_9 = datetime.fromtimestamp(timestamp, tz)
    
    year=dt_9.year
    month="{:%m}".format(dt_9)
    day="{:%d}".format(dt_9)
    
    url='https://api-gw.sports.naver.com/olympic/tokyo2020/games?fromDate=%s-%s-%s&toDate=%s-%s-%s&liveOrKoreanStarted=true&includeManual=true&sort=liveAndPopular&page=1&pageSize=20&fields=all'%(year,month,day,year,month,day)
    htm_data=requests.get(url, headers=heads)
    if(htm_data.status_code!=200):return ''
    json_data=json.loads(htm_data.text)
    lList=json_data ['result'] ['games']
    
    return lList

def get_url(**kwargs):

    return '{0}?{1}'.format(_url, urlencode(kwargs))

def list_categories():

    xbmcplugin.setPluginCategory(_handle, 'Korea Olympic Addon')
    xbmcplugin.setContent(_handle, 'videos')
    categories = ['kbs 올림픽', '네이버 올림픽']

    for category in categories:
        list_item = xbmcgui.ListItem(label=category)
        list_item.setInfo('video', {'title': category})
        url = get_url(action='listing', category=category)
        is_folder = True
        xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
        
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(_handle)


def list_videos(platform):

    if(platform=='kbs 올림픽'):
        gList=get_game_k('kbs')
    elif(platform=='네이버 올림픽'):
        gList = get_game_n()
        if(len(gList)==0):
            img=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','noImage.png')
            mes='현재 진행중인 올림픽 경기 없습니다. 올림픽 중계 시간에만 방송을 시청하실 수 있습니다.'
            list_item = xbmcgui.ListItem(mes)
            list_item.setArt({'thumb': img,'icon': img})
            list_item.setInfo('video', {'title': mes,
                                                'mediatype': 'video',
                                                'plot' : mes})
            list_item.setProperty('IsPlayable', 'false')
            url = get_url(action='play_none', video='ss')
            xbmcplugin.addDirectoryItem(_handle, url, list_item, False)

            xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
            xbmcplugin.endOfDirectory(_handle,cacheToDisc=False)
        else:
            for myObj in gList:
                playID=''
                myLabel=''
                myIsOnair='방송중이 아님'
                if(myObj['gameOnAir'] == True):
                    myIsOnair='방송중'
                    if(myObj['disciplineName'].strip()=='올림픽'):
                        myLabel = '<지상파 방송중> %s - %s'%(myObj['disciplineName'],myObj['title'])
                    elif(myObj['homeTeamCountryName']!='' and myObj['awayTeamCountryName']!=''):
                        myLabel = '<방송중> %s - %s [%s %s : %s %s]'%(myObj['disciplineName'],myObj['title'],myObj['homeTeamCountryName'],myObj['homeTeamScore'],myObj['awayTeamScore'],myObj['awayTeamCountryName'])
                    else:
                        myLabel = '<방송중> %s - %s'%(myObj['disciplineName'],myObj['title'])
                    list_item = xbmcgui.ListItem(myLabel)
                    list_item.setProperty('IsPlayable', 'true')
                    if(myObj.get('liveThumbnail')):
                        img=myObj['liveThumbnail']
                    else:
                        img=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','noImage.png')

                else:
                    img=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','noImage.png')
                    if(myObj['homeTeamCountryName']!='' and myObj['awayTeamCountryName']!=''):
                        myLabel = '%s - %s [%s %s : %s %s]'%(myObj['disciplineName'],myObj['title'],myObj['homeTeamCountryName'],myObj['homeTeamScore'],myObj['awayTeamScore'],myObj['awayTeamCountryName'])  
                    else:
                        myLabel = '%s - %s'%(myObj['disciplineName'],myObj['title'])  
                    list_item = xbmcgui.ListItem(myLabel)
                    list_item.setProperty('IsPlayable', 'false')
                if(myObj['koreaPlayer'] == True and myObj['homeTeamCountryName']!=''):
                    myInfor='%s %s : %s %s\n\n시간: %s %s - %s\n\n%s'%(myObj['homeTeamCountryName'], myObj['homeTeamScore'], myObj['awayTeamScore'], myObj['awayTeamCountryName'], myObj['gameDate'], myObj['gameDateTime'].split('T')[1][:-3], myIsOnair, myObj['stadium'])
                else:
                    myInfor='%s\n\n시간: %s %s - %s'%(myLabel,myObj['gameDate'], myObj['gameDateTime'].split('T')[1][:-3],myIsOnair)
                list_item.setArt({'thumb': img,'icon': img})
                list_item.setInfo('video', {'title': myLabel,
                                            'mediatype': 'video',
                                            'plot' : myInfor})

                if(myObj['hasDetailGameId'] == True):
                    if(myObj.get('detailGameId')):
                        playID=myObj['detailGameId']
                    else:
                        playID=myObj['gameId']
                else:
                    playID=myObj['gameId']
                url = get_url(action='play_naver', video=playID)


                is_folder = False

                xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)

            xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
            xbmcplugin.endOfDirectory(_handle,cacheToDisc=False)

def play_video(gid,platform):
    if(platform=='naver'):

        n_url_init='https://api-gw.sports.naver.com/schedule/games/'+gid+'/lives'
        s_1=requests.get(n_url_init,headers={'User-Agent' : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36', 'Accept' : 'application/json, text/plain, */*', 'accept-encoding' : 'gzip, deflate, br', 'accept-language' : 'ko-KR,ko;q=0.9', 'referer' : 'https://m.sports.naver.com/game/'+gid})
        if(s_1.status_code!=200):return ''
        jso_1=json.loads(s_1.text)
        r_live_id=jso_1 ['result'] ['lives'][0]['liveId']
        
        rurl='https://proxy-gateway.sports.naver.com/livecloud/lives/%s/playback?countryCode=KR&devt=HTML5_PC&timeMachine=true&p2p=true&includeThumbnail=true'%(r_live_id)
        s_2=requests.get(rurl,headers={'User-Agent' : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36', 'Accept' : 'application/json, text/plain, */*', 'accept-encoding' : 'gzip, deflate, br', 'accept-language' : 'ko-KR,ko;q=0.9', 'referer' : 'https://m.sports.naver.com/game/'+gid})
        if(s_2.status_code!=200):return ''
        jso_2=json.loads(s_2.text)
        stream_url=jso_2['media'] [0] ['path']

        play_item = xbmcgui.ListItem(path=stream_url)

        xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)
    elif(platform=='kbs'):
        kurl='https://tokyo2020.kbs.co.kr/api/liveurl?channel='+gid
        htm = requests.get(kurl, headers=heads_ref)
        liveUrl=json.loads(htm.text)['result_url']
        
        play_item = xbmcgui.ListItem(path=liveUrl)

        xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)
    else:
        try:
            xbmcgui.Dialog().notification(addonname,'재생할 수 없는 목록입니다.')
        except:
            None


def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if(noMore==1):
        noUsing('olympic')
    if params:
        if(params['action'] == 'listing'):
            list_videos(params['category'])
        elif params['action'] == 'play_naver':
            play_video(params['video'], 'naver')
        elif params['action'] == 'play_kbs':
            play_video(params['video'], 'kbs')
        elif params['action'] == 'play_none':
            play_video('none', 'none')
        else:
            raise ValueError('Invalid paramstring: {0}!'.format(paramstring))
    else:
        list_categories()
        #get_game_k('kbs')


if __name__ == '__main__':

    first_date = datetime.now()
    end_date=datetime(2021, 8, 9)
    if(first_date>end_date):
        noMore=1
    router(sys.argv[2][1:])
